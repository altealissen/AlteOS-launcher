package com.ioslike.launcher

import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap

data class AppItem(
    val pkg: String,
    val cls: String,
    val label: String,
    val category: Int,
) {
    val key: String get() = "$pkg/$cls"
}

/**
 * Предрендеренные слои иконки (считаются один раз в фоне):
 *  full  – готовая иконка 192x192 (адаптивная: фон+передний план, обрезано по видимой зоне)
 *  fg    – только передний план на холсте 288x288 (108dp-сетка), нужен для стекла и Material You
 *  mono  – монохромный слой (Android 13+), если приложение его поддерживает
 */
class IconBits(
    val full: ImageBitmap,
    val fg: ImageBitmap,
    val mono: ImageBitmap?,
    val dominant: Color,
    val silhouetteOk: Boolean,
)

enum class IconStyle { IOS, MATERIAL_YOU }

class Tonal(val bg: Color, val glyph: Color)

class LauncherSettings(private val sp: SharedPreferences) {
    var style by mutableStateOf(
        runCatching { IconStyle.valueOf(sp.getString("style", "IOS")!!) }.getOrDefault(IconStyle.IOS)
    )
        private set
    var glass by mutableStateOf(sp.getBoolean("glass", true))
        private set
    var labels by mutableStateOf(sp.getBoolean("labels", true))
        private set
    var large by mutableStateOf(sp.getBoolean("large", false))
        private set

    fun updateStyle(v: IconStyle) {
        style = v
        sp.edit().putString("style", v.name).apply()
    }

    fun updateGlass(v: Boolean) {
        glass = v
        sp.edit().putBoolean("glass", v).apply()
    }

    fun updateLabels(v: Boolean) {
        labels = v
        sp.edit().putBoolean("labels", v).apply()
    }

    fun updateLarge(v: Boolean) {
        large = v
        sp.edit().putBoolean("large", v).apply()
    }
}
