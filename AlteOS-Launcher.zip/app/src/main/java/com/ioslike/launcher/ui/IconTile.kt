package com.ioslike.launcher.ui

import android.content.Context
import android.os.Build
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import com.ioslike.launcher.IconBits
import com.ioslike.launcher.IconStyle
import com.ioslike.launcher.Tonal
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sign
import kotlin.math.sin

/** Суперэллипс (n=5) — «squircle» из iOS. */
fun squirclePath(s: Float): Path {
    val p = Path()
    val r = s / 2f
    val steps = 80
    val e = 2.0 / 5.0
    for (i in 0..steps) {
        val t = 2.0 * PI * i / steps
        val c = cos(t)
        val sn = sin(t)
        val x = r + r * (sign(c) * abs(c).pow(e)).toFloat()
        val y = r + r * (sign(sn) * abs(sn).pow(e)).toFloat()
        if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
    }
    p.close()
    return p
}

object SquircleShape : Shape {
    override fun createOutline(size: Size, layoutDirection: LayoutDirection, density: Density): Outline =
        Outline.Generic(squirclePath(size.minDimension))
}

fun tonalColors(ctx: Context, dark: Boolean): Tonal =
    if (Build.VERSION.SDK_INT >= 31) {
        if (!dark) {
            Tonal(
                Color(ctx.getColor(android.R.color.system_accent1_100)),
                Color(ctx.getColor(android.R.color.system_accent1_800)),
            )
        } else {
            Tonal(
                Color(ctx.getColor(android.R.color.system_accent1_800)),
                Color(ctx.getColor(android.R.color.system_accent1_100)),
            )
        }
    } else if (!dark) {
        Tonal(Color(0xFFD6E3FF), Color(0xFF1B3B6F))
    } else {
        Tonal(Color(0xFF254777), Color(0xFFD6E3FF))
    }

@Composable
fun IconTile(
    bits: IconBits?,
    style: IconStyle,
    glass: Boolean,
    size: Dp,
    modifier: Modifier = Modifier,
) {
    val ctx = LocalContext.current
    val dark = isSystemInDarkTheme()
    val tonal = remember(dark) { tonalColors(ctx, dark) }
    val density = LocalDensity.current
    val px = with(density) { size.toPx() }
    val path = remember(px) { squirclePath(px) }
    val base = modifier.size(size)
    Canvas((if (glass) base.shadow(3.dp, SquircleShape, clip = false) else base).clip(SquircleShape)) {
        drawTile(bits, style, glass, tonal, path)
    }
}

private fun DrawScope.glyph(img: ImageBitmap, tint: Color?) {
    val s = size.minDimension
    val g = (s * 1.5f).roundToInt()          // слой 108dp -> плитка 72dp
    val off = -((g - s) / 2f).roundToInt()
    drawImage(
        image = img,
        dstOffset = IntOffset(off, off),
        dstSize = IntSize(g, g),
        colorFilter = if (tint != null) ColorFilter.tint(tint, BlendMode.SrcIn) else null,
        filterQuality = FilterQuality.Medium,
    )
}

private fun DrawScope.glassFinish(path: Path) {
    val s = size.minDimension
    // зеркальный блик сверху-слева
    drawRect(
        Brush.radialGradient(
            listOf(Color.White.copy(alpha = 0.55f), Color.Transparent),
            center = Offset(s * 0.28f, s * 0.10f),
            radius = s * 0.80f,
        )
    )
    // нижнее внутреннее свечение (преломление края)
    drawRect(
        Brush.verticalGradient(
            0.55f to Color.Transparent,
            1f to Color.White.copy(alpha = 0.24f),
        )
    )
    // контур-«ободок»
    drawPath(
        path,
        Brush.linearGradient(
            listOf(Color.White.copy(alpha = 0.95f), Color.White.copy(alpha = 0.08f), Color.White.copy(alpha = 0.6f)),
            start = Offset(0f, 0f),
            end = Offset(s, s),
        ),
        style = Stroke(width = 2.4.dp.toPx()),
    )
}

private fun DrawScope.drawTile(bits: IconBits?, style: IconStyle, glass: Boolean, tonal: Tonal, path: Path) {
    val s = size.minDimension
    if (bits == null) {
        drawRect(Color.White.copy(alpha = 0.18f))
        return
    }
    val whole = IntSize(s.roundToInt(), s.roundToInt())
    when (style) {
        IconStyle.IOS -> if (!glass) {
            drawImage(bits.full, dstSize = whole, filterQuality = FilterQuality.Medium)
            drawPath(path, Color.Black.copy(alpha = 0.07f), style = Stroke(width = 1.dp.toPx()))
        } else {
            val c = bits.dominant
            drawRect(Brush.verticalGradient(listOf(c.copy(alpha = 0.62f), c.copy(alpha = 0.34f))))
            drawRect(Color.White.copy(alpha = 0.10f))
            glyph(bits.fg, null)
            glassFinish(path)
        }

        IconStyle.MATERIAL_YOU -> {
            val themed = bits.mono != null || bits.silhouetteOk
            if (!themed) {
                // приложение без монохромного слоя — оставляем оригинал, как делает Pixel Launcher
                drawImage(bits.full, dstSize = whole, filterQuality = FilterQuality.Medium)
                if (glass) glassFinish(path)
            } else if (!glass) {
                drawRect(tonal.bg)
                glyph(bits.mono ?: bits.fg, tonal.glyph)
            } else {
                drawRect(Brush.verticalGradient(listOf(tonal.bg.copy(alpha = 0.66f), tonal.bg.copy(alpha = 0.38f))))
                drawRect(Color.White.copy(alpha = 0.08f))
                glyph(bits.mono ?: bits.fg, tonal.glyph)
                glassFinish(path)
            }
        }
    }
}
