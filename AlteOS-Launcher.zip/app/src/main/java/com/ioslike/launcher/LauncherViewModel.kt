package com.ioslike.launcher

import android.app.Application
import android.content.Context
import android.content.pm.LauncherApps
import android.os.Handler
import android.os.Looper
import android.os.UserHandle
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class LauncherViewModel(app: Application) : AndroidViewModel(app) {

    private val ctx: Context = app
    private val sp = app.getSharedPreferences("launcher", Context.MODE_PRIVATE)

    val settings = LauncherSettings(sp)
    val apps = mutableStateMapOf<String, AppItem>()
    val icons = mutableStateMapOf<String, IconBits>()
    val home = mutableStateListOf<String>()
    val dock = mutableStateListOf<String>()

    var homeSignal by mutableIntStateOf(0)
        private set

    private var loadedOnce = false
    private var job: Job? = null

    private val launcherApps: LauncherApps? = app.getSystemService(LauncherApps::class.java)

    private val callback = object : LauncherApps.Callback() {
        override fun onPackageRemoved(packageName: String?, user: UserHandle?) = changed(packageName)
        override fun onPackageAdded(packageName: String?, user: UserHandle?) = changed(packageName)
        override fun onPackageChanged(packageName: String?, user: UserHandle?) = changed(packageName)
        override fun onPackagesAvailable(packageNames: Array<out String>?, user: UserHandle?, replacing: Boolean) =
            changed(null)

        override fun onPackagesUnavailable(packageNames: Array<out String>?, user: UserHandle?, replacing: Boolean) =
            changed(null)
    }

    init {
        reload()
        launcherApps?.registerCallback(callback, Handler(Looper.getMainLooper()))
    }

    override fun onCleared() {
        launcherApps?.unregisterCallback(callback)
    }

    private fun changed(pkg: String?) {
        reload(if (pkg == null) emptySet() else setOf(pkg))
    }

    fun homePressed() {
        homeSignal++
    }

    fun reload(dropPkgs: Set<String> = emptySet()) {
        job?.cancel()
        job = viewModelScope.launch {
            val items = withContext(Dispatchers.Default) { AppRepo.query(ctx) }
            val keys = items.map { it.key }.toSet()
            apps.keys.retainAll(keys)
            items.forEach { apps[it.key] = it }
            icons.keys.retainAll(keys)
            if (dropPkgs.isNotEmpty()) {
                icons.keys.removeAll { k -> dropPkgs.contains(apps[k]?.pkg ?: "") }
            }
            mergeLayout(items)

            val priority = (dock + home.take(48)).toSet()
            val missing = items.filter { it.key !in icons }.sortedBy { it.key !in priority }
            withContext(Dispatchers.Default) {
                val batch = ArrayList<Pair<String, IconBits>>()
                for (item in missing) {
                    val d = AppRepo.loadIcon(ctx, item) ?: continue
                    batch += item.key to IconFactory.create(d)
                    if (batch.size >= 12) {
                        val b = ArrayList(batch)
                        batch.clear()
                        withContext(Dispatchers.Main) { b.forEach { icons[it.first] = it.second } }
                    }
                }
                if (batch.isNotEmpty()) {
                    withContext(Dispatchers.Main) { batch.forEach { icons[it.first] = it.second } }
                }
            }
        }
    }

    private fun mergeLayout(items: List<AppItem>) {
        val exist = items.map { it.key }.toSet()

        val curHome: List<String>
        val curDock: List<String>
        if (loadedOnce) {
            curHome = home.toList()
            curDock = dock.toList()
        } else {
            curHome = sp.getString("home", null)?.split("\n") ?: emptyList()
            curDock = if (sp.contains("dock")) {
                sp.getString("dock", "")!!.split("\n")
            } else {
                AppRepo.defaultDock(ctx, items)
            }
        }
        val dockKeys = curDock.filter { it in exist }.distinct().take(4)
        val homeSaved = curHome.filter { it in exist && it !in dockKeys }.distinct()
        val known = HashSet<String>().apply { addAll(homeSaved); addAll(dockKeys) }
        val homeKeys = homeSaved + items.map { it.key }.filter { it !in known }

        if (home.toList() != homeKeys) {
            home.clear()
            home.addAll(homeKeys)
        }
        if (dock.toList() != dockKeys) {
            dock.clear()
            dock.addAll(dockKeys)
        }
        loadedOnce = true
        saveLayout()
    }

    fun saveLayout() {
        sp.edit()
            .putString("home", home.joinToString("\n"))
            .putString("dock", dock.joinToString("\n"))
            .apply()
    }

    fun addToDock(key: String) {
        if (key in dock) return
        home.remove(key)
        if (dock.size >= 4) {
            val last = dock.removeAt(dock.lastIndex)
            home.add(last)
        }
        dock.add(key)
        saveLayout()
    }

    fun removeFromDock(key: String) {
        if (dock.remove(key)) {
            home.add(key)
            saveLayout()
        }
    }
}
