package com.ioslike.launcher.ui

import android.content.pm.ApplicationInfo
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.Canvas
import com.ioslike.launcher.AppItem
import com.ioslike.launcher.IconStyle
import com.ioslike.launcher.LauncherViewModel

private val Accent = Color(0xFF0A84FF)

@Composable
private fun noRipple() = remember { MutableInteractionSource() }

/** Маленькая стеклянная «пилюля» (кнопки + и Готово в режиме редактирования). */
@Composable
fun GlassPill(onClick: () -> Unit, modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    val shape = RoundedCornerShape(50)
    Box(
        modifier
            .clip(shape)
            .background(Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.34f), Color.White.copy(alpha = 0.18f))))
            .border(1.dp, Brush.linearGradient(listOf(Color.White.copy(alpha = 0.7f), Color.White.copy(alpha = 0.1f))), shape)
            .clickable(interactionSource = noRipple(), indication = null, onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 4.dp),
        contentAlignment = Alignment.Center,
    ) { content() }
}

@Composable
fun SearchPill(onClick: () -> Unit, modifier: Modifier = Modifier) {
    GlassPill(onClick, modifier) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Canvas(Modifier.size(13.dp)) {
                val w = 1.8.dp.toPx()
                drawCircle(Color.White, radius = size.minDimension * 0.34f, center = Offset(size.width * 0.42f, size.height * 0.42f), style = Stroke(w))
                drawLine(
                    Color.White,
                    Offset(size.width * 0.66f, size.height * 0.66f),
                    Offset(size.width * 0.95f, size.height * 0.95f),
                    strokeWidth = w,
                )
            }
            BasicText("Search", style = TextStyle(color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium))
        }
    }
}

// ───────────────────────── Контекстное меню ─────────────────────────

class MenuRow(val title: String, val destructive: Boolean = false, val action: () -> Unit)

@Composable
fun ContextMenuOverlay(
    state: MenuState,
    vm: LauncherViewModel,
    onDismiss: () -> Unit,
    rows: List<MenuRow>,
    screenW: Float,
    screenH: Float,
) {
    val dark = isSystemInDarkTheme()
    val density = androidx.compose.ui.platform.LocalDensity.current
    val t = remember { androidx.compose.animation.core.Animatable(0f) }
    LaunchedEffect(Unit) { t.animateTo(1f, spring(dampingRatio = 0.72f, stiffness = 420f)) }
    if (vm.apps[state.key] == null) return

    val menuW = with(density) { 250.dp.toPx() }
    val rowH = with(density) { 48.dp.toPx() }
    val menuH = rowH * rows.size
    val margin = with(density) { 16.dp.toPx() }
    val gap = with(density) { 12.dp.toPx() }
    val x = (state.rect.center.x - menuW / 2f).coerceIn(margin, (screenW - menuW - margin).coerceAtLeast(margin))
    val below = state.rect.bottom + gap + menuH < screenH - margin * 3
    val y = if (below) state.rect.bottom + gap else state.rect.top - gap - menuH

    val menuBg = if (dark) Color(0xEB2C2C2E) else Color(0xEBF2F2F7)
    val txt = if (dark) Color.White else Color.Black

    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.38f * t.value))
            .clickable(interactionSource = noRipple(), indication = null) { onDismiss() }
    ) {
        // «поднятая» иконка
        Box(
            Modifier
                .offset { androidx.compose.ui.unit.IntOffset(state.rect.left.toInt(), state.rect.top.toInt()) }
                .graphicsLayer {
                    val s = 1f + 0.08f * t.value
                    scaleX = s
                    scaleY = s
                }
        ) {
            IconTile(vm.icons[state.key], vm.settings.style, vm.settings.glass, with(density) { state.rect.width.toDp() })
        }
        Column(
            Modifier
                .offset { androidx.compose.ui.unit.IntOffset(x.toInt(), y.toInt()) }
                .graphicsLayer {
                    alpha = t.value
                    scaleX = 0.85f + 0.15f * t.value
                    scaleY = 0.85f + 0.15f * t.value
                    transformOrigin = androidx.compose.ui.graphics.TransformOrigin(0.5f, if (below) 0f else 1f)
                }
                .width(250.dp)
                .shadow(18.dp, RoundedCornerShape(16.dp))
                .clip(RoundedCornerShape(16.dp))
                .background(menuBg)
                .clickable(interactionSource = noRipple(), indication = null) {}
        ) {
            rows.forEachIndexed { i, r ->
                if (i > 0) Box(Modifier.fillMaxWidth().height(0.6.dp).background(txt.copy(alpha = 0.12f)))
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .clickable(interactionSource = noRipple(), indication = null) { r.action() }
                        .padding(horizontal = 16.dp),
                    contentAlignment = Alignment.CenterStart,
                ) {
                    BasicText(
                        r.title,
                        style = TextStyle(color = if (r.destructive) Color(0xFFFF453A) else txt, fontSize = 16.sp),
                    )
                }
            }
        }
    }
}

// ───────────────────────── Настройки (Customize) ─────────────────────────

@Composable
fun IosSwitch(checked: Boolean, onChange: (Boolean) -> Unit) {
    val bg by animateColorAsState(if (checked) Color(0xFF34C759) else Color(0x4D8E8E93), label = "sw")
    val x by animateDpAsState(if (checked) 22.dp else 2.dp, spring(dampingRatio = 0.7f, stiffness = 600f), label = "swx")
    Box(
        Modifier
            .size(51.dp, 31.dp)
            .clip(CircleShape)
            .background(bg)
            .clickable(interactionSource = noRipple(), indication = null) { onChange(!checked) }
    ) {
        Box(
            Modifier
                .offset(x = x, y = 2.dp)
                .size(27.dp)
                .shadow(2.dp, CircleShape)
                .background(Color.White, CircleShape)
        )
    }
}

@Composable
private fun ToggleRow(title: String, checked: Boolean, textColor: Color, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().height(52.dp).padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        BasicText(title, style = TextStyle(color = textColor, fontSize = 17.sp))
        IosSwitch(checked, onChange)
    }
}

@Composable
private fun StyleCard(
    title: String,
    style: IconStyle,
    selected: Boolean,
    vm: LauncherViewModel,
    cardColor: Color,
    textColor: Color,
    modifier: Modifier,
    onClick: () -> Unit,
) {
    val shape = RoundedCornerShape(20.dp)
    val sample = vm.home.take(3)
    Column(
        modifier
            .clip(shape)
            .background(cardColor)
            .border(2.5.dp, if (selected) Accent else Color.Transparent, shape)
            .clickable(interactionSource = noRipple(), indication = null, onClick = onClick)
            .padding(vertical = 14.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            sample.forEach { k -> IconTile(vm.icons[k], style, vm.settings.glass, 42.dp) }
        }
        BasicText(
            title,
            style = TextStyle(
                color = if (selected) Accent else textColor,
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                textAlign = TextAlign.Center,
            ),
        )
    }
}

@Composable
fun SettingsSheet(visible: Boolean, vm: LauncherViewModel, onClose: () -> Unit) {
    val dark = isSystemInDarkTheme()
    val sheet = if (dark) Color(0xF21C1C1E) else Color(0xF2F2F2F7)
    val text = if (dark) Color.White else Color.Black
    val card = if (dark) Color(0xFF2C2C2E) else Color.White
    val s = vm.settings

    AnimatedVisibility(visible, enter = fadeIn(), exit = fadeOut()) {
        Box(
            Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.32f))
                .clickable(interactionSource = noRipple(), indication = null) { onClose() }
        )
    }
    AnimatedVisibility(
        visible,
        modifier = Modifier.fillMaxSize(),
        enter = slideInVertically { it },
        exit = slideOutVertically { it },
    ) {
        Box(Modifier.fillMaxSize()) {
            Column(
                Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(topStart = 34.dp, topEnd = 34.dp))
                    .background(sheet)
                    .clickable(interactionSource = noRipple(), indication = null) {}
                    .navigationBarsPadding()
                    .padding(horizontal = 20.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                Box(
                    Modifier
                        .align(Alignment.CenterHorizontally)
                        .size(36.dp, 5.dp)
                        .clip(CircleShape)
                        .background(text.copy(alpha = 0.25f))
                )
                BasicText("Customize", style = TextStyle(color = text, fontSize = 22.sp, fontWeight = FontWeight.Bold))
                BasicText(
                    "Icon style",
                    style = TextStyle(color = text.copy(alpha = 0.55f), fontSize = 13.sp, fontWeight = FontWeight.Medium),
                )
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    StyleCard("iOS", IconStyle.IOS, s.style == IconStyle.IOS, vm, card, text, Modifier.weight(1f)) {
                        s.updateStyle(IconStyle.IOS)
                    }
                    StyleCard(
                        "Material You", IconStyle.MATERIAL_YOU, s.style == IconStyle.MATERIAL_YOU, vm, card, text, Modifier.weight(1f)
                    ) { s.updateStyle(IconStyle.MATERIAL_YOU) }
                }
                Column(Modifier.clip(RoundedCornerShape(16.dp)).background(card)) {
                    ToggleRow("Liquid Glass", s.glass, text) { s.updateGlass(it) }
                    Box(Modifier.fillMaxWidth().height(0.6.dp).padding(start = 16.dp).background(text.copy(alpha = 0.12f)))
                    ToggleRow("Icon labels", s.labels, text) { s.updateLabels(it) }
                    Box(Modifier.fillMaxWidth().height(0.6.dp).padding(start = 16.dp).background(text.copy(alpha = 0.12f)))
                    ToggleRow("Large icons", s.large, text) { s.updateLarge(it) }
                }
                Spacer(Modifier.height(4.dp))
            }
        }
    }
}

// ───────────────────────── Поиск ─────────────────────────

@OptIn(ExperimentalComposeUiApi::class)
@Composable
fun SearchOverlay(visible: Boolean, vm: LauncherViewModel, onClose: () -> Unit, onLaunch: (AppItem, Rect) -> Unit) {
    AnimatedVisibility(visible, enter = fadeIn(), exit = fadeOut()) {
        var q by remember { mutableStateOf("") }
        val focus = remember { FocusRequester() }
        val kb = LocalSoftwareKeyboardController.current
        LaunchedEffect(Unit) {
            focus.requestFocus()
            kb?.show()
        }
        DisposableEffect(Unit) { onDispose { kb?.hide() } }
        val all = remember(vm.apps.size) { vm.apps.values.sortedBy { it.label.lowercase() } }
        val shown = if (q.isBlank()) all else all.filter { it.label.contains(q, ignoreCase = true) }

        Column(
            Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.6f))
                .windowInsetsPadding(WindowInsets.systemBars)
                .imePadding()
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Box(
                    Modifier
                        .weight(1f)
                        .height(44.dp)
                        .clip(RoundedCornerShape(22.dp))
                        .background(Color.White.copy(alpha = 0.2f))
                        .padding(horizontal = 16.dp),
                    contentAlignment = Alignment.CenterStart,
                ) {
                    BasicTextField(
                        value = q,
                        onValueChange = { q = it },
                        singleLine = true,
                        textStyle = TextStyle(color = Color.White, fontSize = 17.sp),
                        cursorBrush = SolidColor(Color.White),
                        modifier = Modifier.fillMaxWidth().focusRequester(focus),
                        decorationBox = { inner ->
                            if (q.isEmpty()) {
                                BasicText("Search", style = TextStyle(color = Color.White.copy(alpha = 0.55f), fontSize = 17.sp))
                            }
                            inner()
                        },
                    )
                }
                BasicText(
                    "Cancel",
                    modifier = Modifier.clickable(interactionSource = noRipple(), indication = null) { onClose() },
                    style = TextStyle(color = Color.White, fontSize = 17.sp),
                )
            }
            Spacer(Modifier.height(10.dp))
            LazyColumn(Modifier.fillMaxSize()) {
                items(shown, key = { it.key }) { app ->
                    val ref = remember { RectRef() }
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clickable(interactionSource = noRipple(), indication = null) {
                                onLaunch(app, ref.r)
                                onClose()
                            }
                            .padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(14.dp),
                    ) {
                        Box(Modifier.onGloballyPositioned { ref.r = it.boundsInRoot() }) {
                            IconTile(vm.icons[app.key], vm.settings.style, vm.settings.glass, 46.dp)
                        }
                        BasicText(app.label, style = TextStyle(color = Color.White, fontSize = 17.sp))
                    }
                }
            }
        }
    }
}

// ───────────────────────── App Library ─────────────────────────

fun categoryName(c: Int): String = when (c) {
    ApplicationInfo.CATEGORY_GAME -> "Games"
    ApplicationInfo.CATEGORY_AUDIO, ApplicationInfo.CATEGORY_VIDEO, ApplicationInfo.CATEGORY_IMAGE -> "Entertainment"
    ApplicationInfo.CATEGORY_SOCIAL -> "Social"
    ApplicationInfo.CATEGORY_NEWS -> "News"
    ApplicationInfo.CATEGORY_MAPS -> "Travel"
    ApplicationInfo.CATEGORY_PRODUCTIVITY -> "Productivity"
    else -> "Utilities"
}

@Composable
private fun SmallIcon(app: AppItem, size: androidx.compose.ui.unit.Dp, vm: LauncherViewModel, onLaunch: (AppItem, Rect) -> Unit) {
    val ref = remember { RectRef() }
    Box(
        Modifier
            .size(size)
            .onGloballyPositioned { ref.r = it.boundsInRoot() }
            .clickable(interactionSource = noRipple(), indication = null) { onLaunch(app, ref.r) }
    ) {
        IconTile(vm.icons[app.key], vm.settings.style, vm.settings.glass, size)
    }
}

@Composable
fun LibraryPage(vm: LauncherViewModel, onLaunch: (AppItem, Rect) -> Unit, onSearch: () -> Unit) {
    val groups = remember(vm.apps.size) {
        vm.apps.values.groupBy { categoryName(it.category) }.entries.sortedBy { it.key }.map { it.key to it.value }
    }
    val shape = RoundedCornerShape(28.dp)
    Column(
        Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.28f))
            .padding(horizontal = 16.dp)
    ) {
        Spacer(Modifier.height(6.dp))
        Box(
            Modifier
                .fillMaxWidth()
                .height(44.dp)
                .clip(RoundedCornerShape(22.dp))
                .background(Color.White.copy(alpha = 0.2f))
                .clickable(interactionSource = noRipple(), indication = null) { onSearch() }
                .padding(horizontal = 16.dp),
            contentAlignment = Alignment.CenterStart,
        ) {
            BasicText("App Library", style = TextStyle(color = Color.White.copy(alpha = 0.7f), fontSize = 17.sp))
        }
        Spacer(Modifier.height(16.dp))
        LazyVerticalGrid(
            GridCells.Fixed(2),
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            contentPadding = PaddingValues(bottom = 16.dp),
        ) {
            items(groups) { (name, list) ->
                Column {
                    BoxWithConstraints(
                        Modifier
                            .fillMaxWidth()
                            .aspectRatio(1f)
                            .clip(shape)
                            .background(Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.28f), Color.White.copy(alpha = 0.14f))))
                            .border(1.dp, Brush.linearGradient(listOf(Color.White.copy(alpha = 0.6f), Color.White.copy(alpha = 0.08f))), shape)
                            .padding(12.dp)
                    ) {
                        val gap = 10.dp
                        val tile = (maxWidth - gap) / 2
                        Column(verticalArrangement = Arrangement.spacedBy(gap)) {
                            for (r in 0..1) {
                                Row(horizontalArrangement = Arrangement.spacedBy(gap)) {
                                    for (c in 0..1) {
                                        val a = list.getOrNull(r * 2 + c)
                                        Box(Modifier.size(tile)) {
                                            if (a != null) SmallIcon(a, tile, vm, onLaunch)
                                        }
                                    }
                                }
                            }
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                    BasicText(
                        name,
                        modifier = Modifier.fillMaxWidth(),
                        style = LabelStyle.copy(fontSize = 12.sp),
                    )
                }
            }
        }
    }
}
