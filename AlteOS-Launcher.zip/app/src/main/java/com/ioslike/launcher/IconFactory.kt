package com.ioslike.launcher

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.Drawable
import android.os.Build
import androidx.annotation.RequiresApi
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap

object IconFactory {
    private const val S = 192   // размер готовой плитки (72dp * ~2.67)
    private const val L = 288   // слой адаптивной иконки (108dp-сетка), видимая зона = центральные 2/3

    fun create(d: Drawable): IconBits = try {
        if (Build.VERSION.SDK_INT >= 26 && d is AdaptiveIconDrawable) adaptive(d) else legacy(d)
    } catch (t: Throwable) {
        blank()
    }

    private fun blank(): IconBits {
        val full = Bitmap.createBitmap(S, S, Bitmap.Config.ARGB_8888)
        full.eraseColor(0xFF8E8E93.toInt())
        val fg = Bitmap.createBitmap(L, L, Bitmap.Config.ARGB_8888)
        return IconBits(full.asImageBitmap(), fg.asImageBitmap(), null, Color(0xFF8E8E93), false)
    }

    @RequiresApi(26)
    private fun adaptive(d: AdaptiveIconDrawable): IconBits {
        val comp = Bitmap.createBitmap(L, L, Bitmap.Config.ARGB_8888)
        val cc = Canvas(comp)
        drawLayer(cc, d.background)
        drawLayer(cc, d.foreground)

        val fg = Bitmap.createBitmap(L, L, Bitmap.Config.ARGB_8888)
        drawLayer(Canvas(fg), d.foreground)

        var mono: Bitmap? = null
        if (Build.VERSION.SDK_INT >= 33) {
            val m = d.monochrome
            if (m != null) {
                mono = Bitmap.createBitmap(L, L, Bitmap.Config.ARGB_8888)
                drawLayer(Canvas(mono), m)
            }
        }
        val off = (L - S) / 2
        val full = Bitmap.createBitmap(comp, off, off, S, S)
        return IconBits(
            full.asImageBitmap(),
            fg.asImageBitmap(),
            mono?.asImageBitmap(),
            dominant(full),
            silhouetteOk(fg),
        )
    }

    private fun legacy(d: Drawable): IconBits {
        val inset = (S * 0.12f).toInt()
        val full = Bitmap.createBitmap(S, S, Bitmap.Config.ARGB_8888)
        val c = Canvas(full)
        c.drawColor(0xFFF2F2F7.toInt())
        d.setBounds(inset, inset, S - inset, S - inset)
        d.draw(c)

        val fg = Bitmap.createBitmap(L, L, Bitmap.Config.ARGB_8888)
        val c2 = Canvas(fg)
        val size = (S * 0.76f).toInt()
        val o = (L - size) / 2
        d.setBounds(o, o, o + size, o + size)
        d.draw(c2)
        return IconBits(full.asImageBitmap(), fg.asImageBitmap(), null, dominant(fg), silhouetteOk(fg))
    }

    private fun drawLayer(c: Canvas, d: Drawable?) {
        if (d == null) return
        d.setBounds(0, 0, L, L)
        d.draw(c)
    }

    private fun dominant(b: Bitmap): Color {
        val sm = Bitmap.createScaledBitmap(b, 24, 24, true)
        val px = IntArray(24 * 24)
        sm.getPixels(px, 0, 24, 0, 0, 24, 24)
        val hsv = FloatArray(3)
        var r = 0.0
        var g = 0.0
        var bl = 0.0
        var w = 0.0
        for (p in px) {
            val a = p ushr 24
            if (a < 128) continue
            android.graphics.Color.colorToHSV(p, hsv)
            val wt = 0.2 + hsv[1] * hsv[2]
            r += ((p shr 16) and 255) * wt
            g += ((p shr 8) and 255) * wt
            bl += (p and 255) * wt
            w += wt
        }
        if (w == 0.0) return Color(0xFF8E8E93)
        return Color(
            red = (r / w / 255.0).toFloat(),
            green = (g / w / 255.0).toFloat(),
            blue = (bl / w / 255.0).toFloat(),
        )
    }

    /** true, если силуэт переднего плана — это глиф, а не сплошной квадрат (годится для тонировки Material You). */
    private fun silhouetteOk(fg: Bitmap): Boolean {
        val sm = Bitmap.createScaledBitmap(fg, 24, 24, true)
        var n = 0
        for (y in 4 until 20) for (x in 4 until 20) {
            if ((sm.getPixel(x, y) ushr 24) > 200) n++
        }
        return n > 3 && n / 256f < 0.8f
    }
}
