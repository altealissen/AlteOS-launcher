package com.ioslike.launcher.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.animateIntOffsetAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.PressGestureScope
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.PagerState
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedback
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.PointerInputScope
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.unit.Dp
import com.ioslike.launcher.AppItem
import com.ioslike.launcher.AppRepo
import com.ioslike.launcher.LauncherViewModel
import kotlinx.coroutines.delay
import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.min
import kotlin.math.roundToInt

const val PER_PAGE = 24

class DragState {
    var key by mutableStateOf<String?>(null)
    var pos by mutableStateOf(Offset.Zero)
}

data class MenuState(val key: String, val rect: Rect, val fromDock: Boolean)

class UiState {
    var editing by mutableStateOf(false)
    var menu by mutableStateOf<MenuState?>(null)
    var settingsOpen by mutableStateOf(false)
    var searchOpen by mutableStateOf(false)
    val drag = DragState()
}

/** Геометрия сетки 4x6, как на iPhone. */
class Geo(val w: Float, val h: Float, large: Boolean) {
    val padX = w * 0.035f
    val colW = (w - 2 * padX) / 4f
    val rowH = min(h / 6f, w * 0.30f)
    val iconPx = (min(colW * 0.74f, rowH * 0.70f) * (if (large) 1.12f else 1f)).coerceAtMost(colW * 0.9f)
    fun slot(i: Int) = IntOffset((padX + (i % 4) * colW).roundToInt(), ((i / 4) * rowH).roundToInt())
}

@Composable
fun LauncherScreen(vm: LauncherViewModel) {
    val ctx = LocalContext.current
    val view = LocalView.current
    val haptic = LocalHapticFeedback.current
    val density = LocalDensity.current
    val cfg = LocalConfiguration.current
    val ui = remember { UiState() }

    val homePages = maxOf(1, (vm.home.size + PER_PAGE - 1) / PER_PAGE)
    val pager = rememberPagerState(pageCount = { homePages + 1 })

    val wiggleT = rememberInfiniteTransition(label = "wiggle")
    val wiggle = wiggleT.animateFloat(
        initialValue = -1.8f,
        targetValue = 1.8f,
        animationSpec = infiniteRepeatable(tween(115, easing = LinearEasing), RepeatMode.Reverse),
        label = "w",
    )

    var pagerSize by remember { mutableStateOf(IntSize.Zero) }
    var dragEdge by remember { mutableIntStateOf(0) }
    val large = vm.settings.large
    val geo = remember(pagerSize, large) {
        if (pagerSize.width > 0 && pagerSize.height > 0) Geo(pagerSize.width.toFloat(), pagerSize.height.toFloat(), large) else null
    }

    val launch: (AppItem, Rect) -> Unit = { item, r -> AppRepo.launch(ctx, view, item, r) }

    BackHandler(enabled = ui.editing || ui.menu != null || ui.settingsOpen || ui.searchOpen) {
        when {
            ui.searchOpen -> ui.searchOpen = false
            ui.settingsOpen -> ui.settingsOpen = false
            ui.menu != null -> ui.menu = null
            else -> ui.editing = false
        }
    }

    // Кнопка Home: закрыть всё и вернуться на первую страницу
    LaunchedEffect(vm.homeSignal) {
        if (vm.homeSignal > 0) {
            ui.menu = null
            ui.settingsOpen = false
            ui.searchOpen = false
            ui.editing = false
            pager.animateScrollToPage(0)
        }
    }

    // Перетаскивание к краю экрана листает страницу
    LaunchedEffect(dragEdge, ui.drag.key) {
        if (ui.drag.key != null && dragEdge != 0) {
            delay(500)
            while (true) {
                val t = pager.currentPage + dragEdge
                if (t in 0 until homePages) pager.animateScrollToPage(t)
                delay(800)
            }
        }
    }

    val sw = cfg.screenWidthDp.dp
    val dockCellW = (sw - 24.dp) / 4
    val dockIcon = (sw * 0.93f / 4) * 0.74f * (if (large) 1.12f else 1f)
    val dockH = dockIcon + 26.dp

    Box(
        Modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                var total = 0f
                detectVerticalDragGestures(
                    onDragStart = { total = 0f },
                    onDragEnd = {
                        if (total > 140f && !ui.editing && ui.menu == null && !ui.settingsOpen) ui.searchOpen = true
                    },
                    onVerticalDrag = { _, dy -> total += dy },
                )
            }
    ) {
        Column(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.systemBars)) {
            Spacer(Modifier.height(30.dp))

            // ───── страницы ─────
            Box(
                Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .onSizeChanged { pagerSize = it }
                    .pointerInput(ui.editing) {
                        if (!ui.editing) {
                            detectTapGestures(onLongPress = {
                                ui.editing = true
                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            })
                        }
                    }
                    .pointerInput(ui.editing, geo) {
                        if (ui.editing && geo != null) {
                            dragReorder(geo, vm, ui, pager, haptic) { dragEdge = it }
                        }
                    }
            ) {
                HorizontalPager(
                    state = pager,
                    modifier = Modifier.fillMaxSize(),
                    beyondBoundsPageCount = 1,
                ) { page ->
                    Box(
                        Modifier
                            .fillMaxSize()
                            .graphicsLayer {
                                val off = abs((pager.currentPage - page) + pager.currentPageOffsetFraction)
                                alpha = 1f - 0.35f * off.coerceIn(0f, 1f)
                            }
                    ) {
                        if (page < homePages) {
                            if (geo != null) HomePage(page, geo, vm, ui, wiggle, launch)
                        } else {
                            LibraryPage(vm, launch) { ui.searchOpen = true }
                        }
                    }
                }

                // «призрак» перетаскиваемой иконки
                val dk = ui.drag.key
                if (dk != null && geo != null && vm.apps[dk] != null) {
                    val iconDp = with(density) { geo.iconPx.toDp() }
                    Box(
                        Modifier
                            .offset {
                                IntOffset(
                                    (ui.drag.pos.x - geo.iconPx / 2f).roundToInt(),
                                    (ui.drag.pos.y - geo.iconPx / 2f).roundToInt(),
                                )
                            }
                            .graphicsLayer {
                                scaleX = 1.15f
                                scaleY = 1.15f
                                alpha = 0.95f
                            }
                    ) {
                        IconTile(vm.icons[dk], vm.settings.style, vm.settings.glass, iconDp)
                    }
                }
            }

            // ───── точки страниц ─────
            Row(
                Modifier.align(Alignment.CenterHorizontally).padding(top = 8.dp, bottom = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(9.dp),
            ) {
                repeat(homePages + 1) { i ->
                    val sel = pager.currentPage == i
                    val a by animateFloatAsState(if (sel) 1f else 0.4f, label = "dot")
                    Box(
                        Modifier
                            .size(7.dp)
                            .graphicsLayer { alpha = a }
                            .background(Color.White, CircleShape)
                    )
                }
            }

            // ───── Search ─────
            val searchAlpha by animateFloatAsState(if (ui.editing) 0f else 1f, label = "searchA")
            Box(Modifier.align(Alignment.CenterHorizontally).height(34.dp).graphicsLayer { alpha = searchAlpha }) {
                if (!ui.editing) SearchPill({ ui.searchOpen = true })
            }
            Spacer(Modifier.height(8.dp))

            // ───── док ─────
            val dockShape = RoundedCornerShape(36.dp)
            Row(
                Modifier
                    .padding(horizontal = 12.dp)
                    .fillMaxWidth()
                    .height(dockH)
                    .clip(dockShape)
                    .background(Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.32f), Color.White.copy(alpha = 0.16f))))
                    .border(
                        1.dp,
                        Brush.linearGradient(listOf(Color.White.copy(alpha = 0.7f), Color.White.copy(alpha = 0.08f), Color.White.copy(alpha = 0.4f))),
                        dockShape,
                    ),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                vm.dock.forEachIndexed { i, k ->
                    val item = vm.apps[k] ?: return@forEachIndexed
                    androidx.compose.runtime.key(k) {
                        AppCell(
                            item = item,
                            bits = vm.icons[k],
                            settings = vm.settings,
                            iconDp = dockIcon,
                            cellW = dockCellW,
                            cellH = dockH,
                            editing = ui.editing,
                            wiggle = wiggle,
                            sign = if (i % 2 == 0) 1f else -1f,
                            showLabel = false,
                            hidden = false,
                            onTap = { r -> launch(item, r) },
                            onLong = { r ->
                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                ui.menu = MenuState(k, r, true)
                            },
                            onRemove = { AppRepo.uninstall(ctx, item) },
                        )
                    }
                }
            }
            Spacer(Modifier.height(6.dp))
        }

        // ───── шапка режима редактирования ─────
        AnimatedVisibility(
            visible = ui.editing,
            enter = fadeIn() + slideInVertically { -it / 2 },
            exit = fadeOut() + slideOutVertically { -it / 2 },
            modifier = Modifier
                .align(Alignment.TopCenter)
                .windowInsetsPadding(WindowInsets.statusBars)
                .padding(horizontal = 16.dp)
                .fillMaxWidth(),
        ) {
            Row(
                Modifier.height(30.dp).fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                GlassPill({ ui.settingsOpen = true }) {
                    BasicText("+", style = TextStyle(color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Medium))
                }
                GlassPill({ ui.editing = false }) {
                    BasicText("Done", style = TextStyle(color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold))
                }
            }
        }

        // ───── контекстное меню ─────
        val menu = ui.menu
        if (menu != null) {
            val item = vm.apps[menu.key]
            if (item != null) {
                val rows = buildList {
                    add(MenuRow("Edit Home Screen") {
                        ui.menu = null
                        ui.editing = true
                    })
                    if (menu.fromDock) {
                        add(MenuRow("Remove from Dock") {
                            ui.menu = null
                            vm.removeFromDock(menu.key)
                        })
                    } else {
                        add(MenuRow("Add to Dock") {
                            ui.menu = null
                            vm.addToDock(menu.key)
                        })
                    }
                    add(MenuRow("App Info") {
                        ui.menu = null
                        AppRepo.appInfo(ctx, item)
                    })
                    add(MenuRow("Remove App", destructive = true) {
                        ui.menu = null
                        AppRepo.uninstall(ctx, item)
                    })
                }
                ContextMenuOverlay(
                    state = menu,
                    vm = vm,
                    onDismiss = { ui.menu = null },
                    rows = rows,
                    screenW = with(density) { cfg.screenWidthDp.dp.toPx() },
                    screenH = with(density) { cfg.screenHeightDp.dp.toPx() },
                )
            }
        }

        SettingsSheet(visible = ui.settingsOpen, vm = vm, onClose = { ui.settingsOpen = false })
        SearchOverlay(visible = ui.searchOpen, vm = vm, onClose = { ui.searchOpen = false }, onLaunch = launch)
    }
}

@Composable
private fun HomePage(
    page: Int,
    geo: Geo,
    vm: LauncherViewModel,
    ui: UiState,
    wiggle: State<Float>,
    onLaunch: (AppItem, Rect) -> Unit,
) {
    val density = LocalDensity.current
    val ctx = LocalContext.current
    val haptic = LocalHapticFeedback.current
    val keys = vm.home.drop(page * PER_PAGE).take(PER_PAGE)
    val iconDp: Dp = with(density) { geo.iconPx.toDp() }
    val cellW: Dp = with(density) { geo.colW.toDp() }
    val cellH: Dp = with(density) { geo.rowH.toDp() }
    val showLabel = vm.settings.labels && !vm.settings.large

    Box(Modifier.fillMaxSize()) {
        keys.forEachIndexed { slot, k ->
            androidx.compose.runtime.key(k) {
                val item = vm.apps[k]
                if (item != null) {
                    val off by animateIntOffsetAsState(
                        geo.slot(slot),
                        spring(dampingRatio = 0.8f, stiffness = 420f),
                        label = "slot",
                    )
                    AppCell(
                        item = item,
                        bits = vm.icons[k],
                        settings = vm.settings,
                        iconDp = iconDp,
                        cellW = cellW,
                        cellH = cellH,
                        editing = ui.editing,
                        wiggle = wiggle,
                        sign = if ((page * PER_PAGE + slot) % 2 == 0) 1f else -1f,
                        showLabel = showLabel,
                        hidden = ui.drag.key == k,
                        onTap = { r -> onLaunch(item, r) },
                        onLong = { r ->
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            ui.menu = MenuState(k, r, false)
                        },
                        onRemove = { AppRepo.uninstall(ctx, item) },
                        modifier = Modifier.offset { off },
                    )
                }
            }
        }
    }
}

private fun hitIndex(p: Offset, g: Geo, page: Int, n: Int, clamp: Boolean): Int? {
    var col = floor((p.x - g.padX) / g.colW).toInt()
    var row = floor(p.y / g.rowH).toInt()
    if (!clamp && (col !in 0..3 || row !in 0..5)) return null
    col = col.coerceIn(0, 3)
    row = row.coerceIn(0, 5)
    val idx = page * PER_PAGE + row * 4 + col
    return if (idx < n) idx else if (clamp) n - 1 else null
}

/**
 * Режим редактирования: зажать иконку на ~170 мс и тащить — она перестраивает сетку,
 * у края экрана листается страница. Быстрый свайп по-прежнему листает страницы.
 */
private suspend fun PointerInputScope.dragReorder(
    geo: Geo,
    vm: LauncherViewModel,
    ui: UiState,
    pager: PagerState,
    haptic: HapticFeedback,
    onEdge: (Int) -> Unit,
) {
    awaitEachGesture {
        val down = awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
        val startIdx = hitIndex(down.position, geo, pager.currentPage, vm.home.size, false)
            ?: return@awaitEachGesture
        val slop = viewConfiguration.touchSlop

        val cancelled = withTimeoutOrNull(170L) {
            var out = false
            while (!out) {
                val ev = awaitPointerEvent(PointerEventPass.Initial)
                val c = ev.changes.firstOrNull { it.id == down.id }
                if (c == null || !c.pressed || (c.position - down.position).getDistance() > slop) out = true
            }
            true
        }
        if (cancelled != null) return@awaitEachGesture

        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
        var idx = startIdx
        ui.drag.key = vm.home[idx]
        ui.drag.pos = down.position
        var lastSwap = 0L
        val edgePx = 48.dp.toPx()
        try {
            while (true) {
                val ev = awaitPointerEvent(PointerEventPass.Initial)
                val c = ev.changes.firstOrNull { it.id == down.id } ?: break
                c.consume()
                if (!c.pressed) break
                ui.drag.pos = c.position
                onEdge(
                    when {
                        c.position.x < edgePx -> -1
                        c.position.x > geo.w - edgePx -> 1
                        else -> 0
                    }
                )
                val t = hitIndex(c.position, geo, pager.currentPage, vm.home.size, true)
                val now = c.uptimeMillis
                if (t != null && t != idx && now - lastSwap > 200L) {
                    vm.home.add(t, vm.home.removeAt(idx))
                    idx = t
                    lastSwap = now
                }
            }
        } finally {
            ui.drag.key = null
            onEdge(0)
            vm.saveLayout()
        }
    }
}
