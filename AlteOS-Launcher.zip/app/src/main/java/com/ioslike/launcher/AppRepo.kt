package com.ioslike.launcher

import android.app.ActivityOptions
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.net.Uri
import android.provider.MediaStore
import android.provider.Settings
import android.view.View
import androidx.compose.ui.geometry.Rect

object AppRepo {

    @Suppress("DEPRECATION")
    fun query(ctx: Context): List<AppItem> {
        val pm = ctx.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(intent, 0)
            .filter { it.activityInfo.packageName != ctx.packageName }
            .map {
                AppItem(
                    pkg = it.activityInfo.packageName,
                    cls = it.activityInfo.name,
                    label = it.loadLabel(pm).toString(),
                    category = it.activityInfo.applicationInfo.category,
                )
            }
            .distinctBy { it.key }
            .sortedBy { it.label.lowercase() }
    }

    fun loadIcon(ctx: Context, item: AppItem): Drawable? = try {
        val pm = ctx.packageManager
        pm.getActivityInfo(ComponentName(item.pkg, item.cls), 0).loadIcon(pm)
    } catch (e: Exception) {
        null
    }

    /** Телефон, сообщения, браузер, камера — как в доке iPhone. */
    @Suppress("DEPRECATION")
    fun defaultDock(ctx: Context, items: List<AppItem>): List<String> {
        val pm = ctx.packageManager
        val intents = listOf(
            Intent(Intent.ACTION_DIAL),
            Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")),
            Intent(Intent.ACTION_VIEW, Uri.parse("https://example.com")),
            Intent(MediaStore.ACTION_IMAGE_CAPTURE),
        )
        return intents
            .mapNotNull { pm.resolveActivity(it, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName }
            .mapNotNull { p -> items.firstOrNull { it.pkg == p }?.key }
            .distinct()
            .take(4)
    }

    fun launch(ctx: Context, view: View, item: AppItem, r: Rect) {
        val intent = Intent(Intent.ACTION_MAIN)
            .addCategory(Intent.CATEGORY_LAUNCHER)
            .setComponent(ComponentName(item.pkg, item.cls))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        try {
            val opts = ActivityOptions.makeScaleUpAnimation(
                view, r.left.toInt(), r.top.toInt(), r.width.toInt().coerceAtLeast(1), r.height.toInt().coerceAtLeast(1)
            )
            ctx.startActivity(intent, opts.toBundle())
        } catch (e: Exception) {
            try {
                ctx.startActivity(intent)
            } catch (_: Exception) {
            }
        }
    }

    fun uninstall(ctx: Context, item: AppItem) {
        try {
            ctx.startActivity(
                Intent(Intent.ACTION_DELETE, Uri.parse("package:${item.pkg}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (_: Exception) {
        }
    }

    fun appInfo(ctx: Context, item: AppItem) {
        try {
            ctx.startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${item.pkg}"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (_: Exception) {
        }
    }
}
