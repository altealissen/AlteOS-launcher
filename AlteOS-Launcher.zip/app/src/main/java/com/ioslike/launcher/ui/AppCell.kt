package com.ioslike.launcher.ui

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ioslike.launcher.AppItem
import com.ioslike.launcher.IconBits
import com.ioslike.launcher.LauncherSettings

class RectRef {
    var r: Rect = Rect.Zero
}

val LabelStyle = TextStyle(
    color = Color.White,
    fontSize = 11.5.sp,
    fontWeight = FontWeight.Medium,
    textAlign = TextAlign.Center,
    shadow = Shadow(Color(0x73000000), Offset(0f, 1.5f), 5f),
)

@Composable
fun AppCell(
    item: AppItem,
    bits: IconBits?,
    settings: LauncherSettings,
    iconDp: Dp,
    cellW: Dp,
    cellH: Dp,
    editing: Boolean,
    wiggle: State<Float>,
    sign: Float,
    showLabel: Boolean,
    hidden: Boolean,
    onTap: (Rect) -> Unit,
    onLong: (Rect) -> Unit,
    onRemove: () -> Unit,
    modifier: Modifier = Modifier,
) {
    var pressed by remember { mutableStateOf(false) }
    val press by animateFloatAsState(
        if (pressed) 0.9f else 1f,
        spring(dampingRatio = 0.55f, stiffness = 500f),
        label = "press",
    )
    val ref = remember { RectRef() }

    Box(
        modifier
            .size(cellW, cellH)
            .graphicsLayer {
                alpha = if (hidden) 0f else 1f
                if (editing) rotationZ = wiggle.value * sign
            }
            .pointerInput(editing) {
                detectTapGestures(
                    onPress = {
                        pressed = true
                        tryAwaitRelease()
                        pressed = false
                    },
                    onTap = { if (!editing) onTap(ref.r) },
                    onLongPress = { if (!editing) onLong(ref.r) },
                )
            },
        contentAlignment = Alignment.Center,
    ) {
        Column(
            Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            Box(
                Modifier
                    .graphicsLayer {
                        scaleX = press
                        scaleY = press
                        alpha = if (pressed) 0.8f else 1f
                    }
                    .onGloballyPositioned { ref.r = it.boundsInRoot() }
            ) {
                IconTile(bits, settings.style, settings.glass, iconDp)
            }
            if (showLabel) {
                Spacer(Modifier.height(5.dp))
                BasicText(
                    item.label,
                    modifier = Modifier.width(cellW - 4.dp),
                    style = LabelStyle,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
        if (editing) {
            Box(
                Modifier
                    .align(Alignment.TopStart)
                    .offset(x = (cellW - iconDp) / 2 - 7.dp, y = (cellH - iconDp) / 2 - (if (showLabel) 14.dp else 7.dp))
                    .size(24.dp)
                    .padding(2.dp)
                    .clip(CircleShape)
                    .background(Color(0xE6D1D1D6))
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                        onClick = onRemove,
                    ),
                contentAlignment = Alignment.Center,
            ) {
                Box(Modifier.size(10.dp, 2.dp).background(Color(0xFF3A3A3C)))
            }
        }
    }
}
